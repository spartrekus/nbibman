

#include <stdlib.h>
#include <stdio.h>
#include <dirent.h>
#include <string.h>
#include <string.h>

// for fexist
#include <ctype.h>
#include <sys/stat.h>
#include <dirent.h>
#include <sys/types.h>

#include <unistd.h>  //define getcwd
#include <ncurses.h>

// tui ncurses 
#include "lib-tui.c"



char *basename(name)
  char *name;
{
  char *base = name;

  while (*name)
    {
      if (*name++ == '/')
	{
	  base = name;
	}
    }
  return (base);
}








////////////////////////////////////////////////
////////////////////////////////////////////////
////////////////////////////////////////////////
////////////////////////////////////////////////
////////////////////////////////////////////////
int main( int argc, char *argv[])
{
    int aoption = 1 ; 
    char myfiletoopen[PATH_MAX];
    strncpy( myfiletoopen, "" , PATH_MAX );

    if ( argc >= 2 ) strncpy( myfiletoopen, argv[ 1 ] , PATH_MAX );

   FILE *fpout;
   char currentrefarticle[PATH_MAX];

   //chdirhome();
   char dbfile[PATH_MAX];
   strncpy( dbfile, "", PATH_MAX );
   strncat( dbfile , getenv( "HOME" ) , PATH_MAX - strlen( dbfile ) - 1);
   strncat( dbfile , "lib.bib" , PATH_MAX - strlen( dbfile ) - 1);


    ////////////////////////////////////////////////////////
    if ( argc == 3)
      if ( strcmp( argv[1] , "--import" ) ==  0 ) 
      if ( strcmp( argv[2] , "" ) !=  0 ) 
      if ( fexist( argv[2] ) ==  1 ) 
      if ( filelinecount( argv[ 2 ]  ) <=  500 ) 
      if ( fexist(  dbfile    ) ==  1 ) 
      {
          printf( "Import %s ...\n", argv[2] );
	  ncat( dbfile, argv[ 2 ] ); 
          return 0;
      }

    ////////////////////////////////////////////////////////
    if ( argc == 2)
      if ( strcmp( argv[1] , "--edit" ) ==  0 ) 
      if ( fexist(  dbfile    ) ==  1 ) 
      {
          printf( "VIM ...\n");
	  nrunwith( " vim " , dbfile );
          return 0;
      }




    nstartncurses( ); 

    ////////////////////
    char tinypager_filesource[PATH_MAX];
    strncpy( tinypager_filesource , myfiletoopen, PATH_MAX );
    int filelinemax = filelinecount( tinypager_filesource );

    int rows, cols ;
    getmaxyx( stdscr, rows , cols);
    int y1 = 0; 
    int x1 = 0 ; 
    int y2 = rows; 
    int x2 = cols;
    int icol = 0; 
    icol = 11;
    void colorstatusbar(){attroff( A_REVERSE); color_set( icol , NULL ); }
    void colorblue(){ attroff( A_REVERSE); color_set( icol , NULL ); }
    void colordefault(){ attroff(A_REVERSE ); color_set( icol , NULL ); }

    ////////////////////
    char mypathbefore[PATH_MAX];
    int scrolly = 0 ; 
    ////////////////////
    int tinypager_view_selectline = 0 ; 
    int tinypager_modeview = 0;
    ////////////////////
    int tinypager_view_scrollx = 0 ;
    int tinypager_view_tabselect = 0 ;
    int tinypager_nfestivalmode = 0 ;
    int tinypager_colorscheme = 1;
    int tinypager_key_genter_automode = 0 ;
    int tinypager_block_linestart = 0 ;
    int tinypager_block_lineend = 0 ;
    int posxcounter = 0 ;
    ////////////////////
    char cncfileopen[PATH_MAX];
    char linetmp[PATH_MAX];
    FILE *fp ;
    int i , j , k , foo ; 

    char cwd[PATH_MAX];
    char fooline[PATH_MAX];
    char currentdatalistfile[PATH_MAX];
    char ndataviewer_string[PATH_MAX];
    char long_clipboard[PATH_MAX];
    int ch ; 
    char filein[PATH_MAX];
    char fileout[PATH_MAX];

    char tinypager_pathbefore[PATH_MAX];
    strncpy( tinypager_pathbefore, getcwd( cwd, PATH_MAX ) , PATH_MAX );


    // clean the ref file (clipboard)
    strncpy( fooline, currentrefarticle, PATH_MAX );
    {
	   chdirhome();
           fpout = fopen( ".references.clp" , "wb+" ) ; 
	   fputs( "\n", fpout );
    	   fclose( fpout );
    }

    // restore the dir
    chdir( tinypager_pathbefore); 






    char tinypager_macro_quick[PATH_MAX];
    strncpy( tinypager_macro_quick, "", PATH_MAX);
    char line[PATH_MAX];
    char cmdi[PATH_MAX];
    char currentline[PATH_MAX];
    strncpy( currentline , "" , PATH_MAX );
    char filetarget[PATH_MAX];
    strncpy( filetarget , "" , PATH_MAX );
    int  tinypager_linemax = 0;
    int  myselection = 0;
    int posy = 0 ;
    int posx = 0 ;
    curs_set( 0 ) ;
    char tinypager_statusmessage[PATH_MAX];
    strncpy( tinypager_statusmessage, "" , PATH_MAX);


    char appfilter[PATH_MAX];
    strncpy( appfilter, "" , PATH_MAX);



	 int articlecountmax = 0;





  void tinypager_statusmessage_draw(){
         int stsmsgposy = rows;
         // TOP
	 colorstatusbar();
         attron( A_REVERSE );
         for ( j = x1+0 ; ( j <= cols ) ; j++) 
            mvaddch( y1+0 ,   j , ' ' ); 
         for ( j = x1+0 ; ( j <= cols ) ; j++) 
            mvaddch( stsmsgposy , j , ' ' ); 
	 mvprintw( 0, 0, " NBIBMAN (GNU) " );
         // BOTTOM
	 colorstatusbar(); attron( A_REVERSE );
	 mvaddch( stsmsgposy , x1 + 0, ACS_VLINE );
	 printw( "%s", strcut(basename( tinypager_filesource ) , 1 ,   15 ) );
	 addch( ACS_VLINE );
	 printw( "Sel:%d", myselection );
	 printw( "/%d", filelinemax);
	 addch( ACS_VLINE );
	 printw( "Scrll:%d", scrolly );
	 addch( ACS_VLINE );
	 printw( "Art:%d", articlecountmax );
	 addch( ACS_VLINE );
	 printw( "%d", tinypager_modeview );
	 addch( ACS_VLINE );
	 printw( "%d", tinypager_view_selectline );
	 addch( ACS_VLINE );

         if ( strcmp( tinypager_statusmessage, "" ) != 0){
          colorstatusbar();
          for ( j = x1 + 0 ; ( j <= cols -1 ) ; j++) 
             mvaddch( stsmsgposy ,  j , ' ' ); 

	     mvprintw( stsmsgposy , x1 + 0 , "[STATUS:%s]", tinypager_statusmessage );
          strncpy( tinypager_statusmessage, "", PATH_MAX );
	 }
  }



  int fooijk; 
  int articlefichecount = 0;
  int articleitem = 0; 
  char myfiche[50][PATH_MAX];
  char myfiche_title[PATH_MAX];
  char myfiche_author[PATH_MAX];
  char myfiche_reference[PATH_MAX];
  char myfiche_pdfdoc[PATH_MAX];
  char myfiche_pdfurl[PATH_MAX];
  char myfiche_url[PATH_MAX];
  void ficheclear( ){
      strncpy( myfiche_title, "", PATH_MAX );
      strncpy( myfiche_author, "", PATH_MAX );
      strncpy( myfiche_reference, "", PATH_MAX );
      strncpy( myfiche_url, "", PATH_MAX );
      strncpy( myfiche_pdfdoc, "", PATH_MAX );
      strncpy( myfiche_pdfurl, "", PATH_MAX );
      int taki;
      for( taki = 0; taki < 49 ; taki++)
         strncpy( myfiche[ taki ], "", PATH_MAX );
  }
  ficheclear( );



  int articlecheck( char *linetuf ){
    int ouino = 0;
    if ( strstr( linetuf , "@article" ) != 0 ) ouino = 1; 
    else if ( strstr( linetuf , "@incollection" ) != 0 ) ouino = 1; 

    return ouino; 
  }

  void fichedraw(  )
  {
     int taki ; 
     attroff( A_REVERSE );
     for( taki = 1; taki < 49 ; taki++)
      if  ( taki <= rows-2 )
      {
       mvaddch( taki , cols/2 ,  ACS_VLINE);
       printw( "%s" ,  strcut( strrlf( myfiche[ taki ] ) , 1 , cols/2 -3 ));
      }

  }


  ///////// tinypager draw
  char getlinestring[PATH_MAX];
  int tinypager_show_basename = 0 ;
 


  void tinypager_draw( int showdraw ){
         strncpy(getlinestring, "", PATH_MAX );
	 int beginfound = 0;
	 int linereadcount = 0;
	 int articlecount = 0;
         strncpy( currentline , "" , PATH_MAX );
         if ( tinypager_view_tabselect < 0 ) tinypager_view_tabselect = 0 ;
         if ( tinypager_view_selectline < 0 ) tinypager_view_selectline = 0 ; 
         if ( scrolly <= 0 ) scrolly = 0;
         if ( myselection <= 0 ) myselection = 0;
         if ( myselection > articlecountmax ) myselection = articlecountmax; 
         posxcounter = 0 ;
	 colorblue();
         ncerase();
         tinypager_linemax = 0;
	 posx = 0;
         if (  fexist( tinypager_filesource ) == 1) 
         {
            fp = fopen( tinypager_filesource , "rb" ) ; 
	    posy = 1 ; 
            posxcounter = 0 ;
            while (( posy <= rows -2 ) && (!feof(fp)) ) 
            {
               fgets( linetmp, PATH_MAX , fp ); 
	       strncpy( line , strrlf( linetmp ),  PATH_MAX );

	       beginfound = articlecheck( line );

               // FILTER
	       if ( beginfound == 1 ) 
                  if ( strcmp( appfilter, "" ) != 0 ) 
		  {
		    if ( strstr( line, appfilter ) == 0 ) 
		    {
		       beginfound = 0;  
	               articleitem = 0; 
		    }
		  }

	       if ( beginfound == 1 ) linereadcount++;
	       if ( beginfound == 1 ) articlecount++;

	       if ( beginfound == 1 ) 
	       if ( articlecount == myselection ) 
	       if ( articlecount != 0 ) 
               {
                   for( fooijk = 0; fooijk < 49 ; fooijk++) strncpy( myfiche[ fooijk ], "", PATH_MAX );
	           strncpy( myfiche[ 1 ], strsplit( strsplit( line , '{', 2 ), ',' , 1 ) , PATH_MAX );
	           strncpy( currentrefarticle, myfiche[ 1 ] , PATH_MAX );
		   strncpy( myfiche_reference, myfiche[ 1 ] , PATH_MAX );
	           articleitem = 2; 
               }
	       if ( beginfound == 0 ) 
	       if ( strcmp( myfiche[ 1 ] , "" ) != 0 ) 
	       if ( articlecount == myselection ) 
               {
	           strncpy( myfiche[ articleitem++ ], line  , PATH_MAX );
		   if ( strstr( line, "author =" ) != 0 ) strncpy( myfiche_author, strsplit(line, '"', 2)   , PATH_MAX );
		   if ( strstr( line, "pdfdoc =" ) != 0 ) strncpy( myfiche_pdfdoc, strsplit(line, '"', 2)   , PATH_MAX );

		   if ( line[0] == 'u' ) if ( line[1] == 'r' ) if ( line[2] == 'l' ) 
		   if ( strstr( line, "url =" ) != 0 ) strncpy( myfiche_url, strsplit(line, '"', 2)   , PATH_MAX );

		   if ( strstr( line, "pdfurl =" ) != 0 ) strncpy( myfiche_pdfurl, strsplit(line, '"', 2)   , PATH_MAX );

		   if ( line[0] == 't' ) if ( line[1] == 'i' ) if ( line[2] == 't' ) 
		   if ( strstr( line, "title =" ) != 0 )  strncpy( myfiche_title, strsplit(line,'"',2) , PATH_MAX );
               }


               if ( !feof(fp) )
	       if ( beginfound == 1 ) 
	       if ( linereadcount >= scrolly )
	       if ( posy <= rows-3 )
               {

                   attroff( A_REVERSE );
		   if ( articlecount == myselection ) 
		   {
                      attron( A_REVERSE );
		   }
                   mvprintw( posy, 1, "%s", strcut( line, 1, cols -1 ) );  
		   posy++;
               }

            }
	    articlecountmax = articlecount--;
            fclose( fp );
         }
         attroff( A_REVERSE );
         attroff( A_BOLD );
    }


   void nbibman_viewtxtpdf()
   {
	    if ( strcmp( myfiche_pdfurl , "" ) != 0 ){
              strncpy( cwd, " wget ", PATH_MAX );
              strncat( cwd , " \"" , PATH_MAX - strlen( cwd ) - 1);
              strncat( cwd , myfiche_pdfurl , PATH_MAX - strlen( cwd ) - 1);
              strncat( cwd , "\" -O /tmp/doc.pdf ; cd /tmp ; pdftotext doc.pdf ; ncview doc.txt " , PATH_MAX - strlen( cwd ) - 1);
              ncruncmd(  cwd );
	    }
   }


   strncpy( tinypager_filesource , dbfile , PATH_MAX );
   int tinypager_gameover = 0;
   while ( tinypager_gameover == 0)
   {
       getmaxyx( stdscr, rows , cols);
       strncpy( currentrefarticle, "", PATH_MAX );
       attroff( A_BOLD);
       colorblue();
       ficheclear(); 
       tinypager_draw( 1 );
       fichedraw(); 
       tinypager_statusmessage_draw();
       strncpy( currentdatalistfile, getlinestring, PATH_MAX );

       nccolorblack();
       attroff( A_BOLD);
       attroff( A_REVERSE);
       nchspace( rows-2 , 0, cols -1 );
       nchspace( rows-1 , 0, cols -1 );
       mvprintw( rows-2 , 0, "%s", myfiche_title );

       curs_set( 0 ); ch = getch(); curs_set( 1 ) ;
       colordefault();


       switch( ch ){
	  case KEY_GFUNCF10:
	  case 'q':
	  case 'i':
                tinypager_gameover = 1;
		break;

	  case 'e':
                foo = ncwin_question( "Edit the item?" );
                if (  foo == 1 ) 
                {
                }
		break;

	  case 'y':
	        strncpy( fooline, currentrefarticle, PATH_MAX );
                if ( strcmp( fooline  , "" ) != 0 )
                {
		   chdirhome();
                   fpout = fopen( ".references.clp" , "ab+" ) ; 
		      fputs( "\\cite{", fpout );
		      fputs( fooline, fpout );
		      fputs( "}", fpout );
		      fputs( "\n", fpout );
		   fclose( fpout );
                }
		break;

	  case 'c':
                     colordefault(); attron( A_REVERSE ); nchspace(  1, 0 , cols-1 );
                     strncpy( fooline , ncwin_inputbox( "MKDIR", "" ), PATH_MAX );
                     if ( strcmp(  fooline  , "" ) != 0 )
                     {
                     }
		break;


	case 's':
            tinypager_view_selectline++;
            break;



	case 'H':
            tinypager_view_scrollx--;
            break;

	case '(':
            tinypager_view_scrollx--;
            tinypager_view_scrollx--;
            tinypager_view_scrollx--;
            tinypager_view_scrollx--;
            tinypager_view_scrollx--;
            break;

	case 'l':
	case 'L':
            tinypager_view_scrollx++;
            break;


	case ')':
            tinypager_view_scrollx++;
            tinypager_view_scrollx++;
            tinypager_view_scrollx++;
            tinypager_view_scrollx++;
            tinypager_view_scrollx++;
            break;



	  case 'g':
	    colorblue(); attron( A_REVERSE );
	    mvprintw( rows-1, x1+0 , "g" ); 
	    colorblue(); attroff( A_REVERSE );
	    ch = getch();
	    switch ( ch ) {
	      case 'g':
	       tinypager_view_selectline=1;
               scrolly = 0 ; 
               myselection = 0 ; 
	       break;
	    }
	    ch = 0;
	    break;


            case 'v':
              if ( fexist( tinypager_filesource ) == 1 )
                 ncrunwith(  " vim " , tinypager_filesource ); 
              break;

	  case 'f':
               nccolorblack();
               strncpy( appfilter , ncwin_inputbox( "FILTER",  "" ), PATH_MAX );
	       tinypager_view_selectline=1;
               scrolly = 0 ; 
               myselection = 0 ; 
	       break;



	  case KEY_GCTRLB:
		chdirhome();
                fpout = fopen( ".references.clp" , "wb" ) ; 
		fclose( fpout );
	        break;


	  case KEY_GBACKSPACE:
	  case KEY_GSPACE:
               nccolorblack();
               strncpy( appfilter , "" , PATH_MAX );
	       tinypager_view_selectline = 1;
               scrolly = 0 ; 
               myselection = 0 ; 
	       break;


	  case 'd':
	  case 'n':
            scrolly += 4 ;
            myselection += 4 ;
            if ( tinypager_modeview == 2 )
             tinypager_view_selectline += 4;

            if ( tinypager_modeview == 3 )
             tinypager_view_selectline += 4;
	    break;

	  case 'r':
	    chdirhome();
	    ncrunwith( " ncview " , ".references.clp" );
	    break;

	  case 'k':
            myselection -= 1 ;
	    break;

	  case 'j':
            myselection += 1 ;
	    break;

	  case 'u':
            scrolly -= 4 ;
            myselection -= 4 ;
            if ( tinypager_modeview == 2 )
             tinypager_view_selectline -= 4;
            if ( tinypager_modeview == 3 )
             tinypager_view_selectline -= 4;
	    break;


	  case KEY_GCTRLT:
            ncrunwith( " ncapplications ", tinypager_filesource );
	    break;

	  case '#':
            switch ( icol )
            {
            case 0:
            icol = 2; 
	    break;
            case 2:
            icol = 3; 
	    break;
            case 3:
            icol = 11; 
	    break;
            case 11:
            icol = 0; 
	    break;
            }
	    break;


	       ////////////// menu
	       //
               case 'm':
                 nccolorblack();
                 mvprintw( rows-1, cols-3, "[m]");
                 i = ncwin_panmenu( "MENU", "view url;view txt/pdf;");
                 if ( i == 1 ) {  
	            if ( strcmp( myfiche_url , "" ) != 0 ){
                       strncpy( cwd, " elinks ", PATH_MAX );
                       strncat( cwd , " \"" , PATH_MAX - strlen( cwd ) - 1);
                       strncat( cwd , myfiche_url , PATH_MAX - strlen( cwd ) - 1);
                       strncat( cwd , "\" " , PATH_MAX - strlen( cwd ) - 1);
                       ncruncmd(  cwd );
		    }
		 }
                 else if ( i == 2 ) {   nbibman_viewtxtpdf();  }
		 break;


	  case 'o':
            nbibman_viewtxtpdf(); 
	    break;

      }
    }

    curs_set( 1 ) ;
    attroff( A_BOLD );
    attroff( A_REVERSE );
    curs_set( 1 );
    endwin();		
    return 0;
}





